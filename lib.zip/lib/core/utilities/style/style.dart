import 'package:truckgo_project/core/core.dart';

// final title_1 =
//     TextStyle(fontSize: 24, fontFamily: "Avenir Heavy");
//     final title_2 =
//     TextStyle(fontSize: 20, fontFamily: "Avenir Heavy");
// final title_3 =
//     TextStyle(fontSize: 20, fontFamily: "Avenir Medium");

//  final body1 =     TextStyle(fontSize: 16, fontFamily: "Avenir Heavy");
//   final body2 =
//     TextStyle(fontSize: 16, fontFamily: "Avenir Medium");
//      final body3 =
//     TextStyle(fontSize: 14, fontFamily: "Avenir Heavy");
//      final body4 =
//     TextStyle(fontSize: 14, fontFamily: "Avenir Medium");
//      final caption1 =
//     TextStyle(fontSize: 12, fontFamily: "Avenir Heavy");
//       final caption2 =
//     TextStyle(fontSize: 12, fontFamily: "Avenir Medium");

final textform_hint_textstyle = TextStyle(
  fontSize: 16,
  fontFamily: "Avenir Medium",
  color: Netural_3_Colour,
  // fontWeight: FontWeight.w200
);
final distinguish_car_style = TextStyle(
  fontSize: 12,
  fontFamily: "Avenir Heavy",
  color: Accent_color,
  // fontWeight: FontWeight.w200
);
final submit_button_style = TextStyle(
  fontSize: 16,
  fontFamily: "Avenir Medium",
  color: Netural_5_Colour,
  // fontWeight: FontWeight.w200
);
TextStyle truck_name_style({Color? color}) => TextStyle(
      fontSize: 15,
      fontFamily: "Avenir Heavy",
      color: color,
      // fontWeight: FontWeight.w200
    );
TextStyle truck_desc_style({Color? color}) => TextStyle(
      fontSize: 12,
      fontFamily: "Avenir Medium",
      color: color,
      // fontWeight: FontWeight.w200
    );
final bottomsheet_title = TextStyle(
  fontSize: 20,
  fontFamily: "Avenir Heavy",
  color: Netural_1_Colour,
  // fontWeight: FontWeight.w200
);
final bottomsheet_content = TextStyle(
    fontSize: 16, fontFamily: "Avenir Heavy", color: Netural_1_Colour);

final numberof_vehicle_style = TextStyle(
  fontSize: 16,
  fontFamily: "Avenir Medium",
  color: Netural_1_Colour,
  // fontWeight: FontWeight.w200
);

    TextStyle bottomsheet_selected_style({Color? color, String? fontfamily}) => TextStyle(
  fontSize: 17,
  fontFamily: fontfamily,
  color: color,
  // fontWeight: FontWeight.w200
);

final row_bottomsheet_content_style = TextStyle(
  fontSize: 14,
  fontFamily: "Avenir Medium",
  color: Netural_3_Colour,
  // fontWeight: FontWeight.w200
);
TextStyle textformfield_error_style(Color color) => TextStyle(
    fontSize: 12, fontFamily: "Avenir Heavy", color: color);
final title_style = TextStyle(
  fontSize: 20,
  fontFamily: "Avenir Medium",
  color: Netural_1_Colour,
  // fontWeight: FontWeight.w200
);
final drop_down_style = TextStyle(
  fontSize: 20,
  fontFamily: "Avenir Medium",
  color: Netural_1_Colour,
  // fontWeight: FontWeight.w200
);
final heading_style = TextStyle(
  fontSize: 16,
  fontFamily: "Avenir Heavy",
  color: Netural_1_Colour,
  // fontWeight: FontWeight.w200
);

final Main_heading_title = TextStyle(
    fontSize: 22, fontFamily: 'Avenir_Medium', color: Netural_5_Colour);
final doller_style = TextStyle(
  fontSize: 15,
  fontFamily: "Avenir Heavy",
  color: Accent_color,
  // fontWeight: FontWeight.w200
);
final order_style = TextStyle(
  fontSize: 14,
  fontFamily: "Avenir Medium",
  color: Netural_1_Colour,
);
final status_style = TextStyle(
  fontSize: 14,
  fontFamily: "Avenir Medium",
  color: Netural_2_Colour,
);
final see_details_style = TextStyle(
  fontSize: 14,
  fontFamily: "Avenir Medium",
  color: Primary_color,
);
final dound_driver_style = TextStyle(
  fontSize: 14,
  fontFamily: "Avenir Heavy",
  color: Accent_color,
  // fontWeight: FontWeight.w200
);
final tab_button_style = TextStyle(
  fontSize: 16,
  fontFamily: "Avenir Heavy",
  color: Netural_5_Colour,
  // fontWeight: FontWeight.w200
);
final License_plate_style = TextStyle(
  fontSize: 14,
  fontFamily: "Avenir Medium",
  color: light_grey_Colour,
);
TextStyle stepper_title_style({Color? color}) => TextStyle(
  fontSize: 16,
  fontFamily: "Avenir Medium",
  color: color,
);
final state_style = TextStyle(
  fontSize: 14,
  fontFamily: "Avenir Heavy",
  color: Netural_2_Colour,
);



    



// final number_of_vehical_style =
//     TextStyle(fontSize: 16, fontWeight: FontWeight.w500);
//      final sub_heading = TextStyle(
//                               fontSize: 18, fontWeight: FontWeight.w600);
