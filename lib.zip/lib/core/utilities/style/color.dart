// ignore_for_file: prefer_const_declarations

import 'package:truckgo_project/core/core.dart';



Color Primary_color = Color(0xff4964D8);
Color Accent_color = Color(0xffFFAF2A);

// netural
Color Netural_1_Colour = Color(0xff343434);
Color Netural_2_Colour = Color(0xffA8A8A8);
Color Netural_3_Colour = Color(0xffCACACA);
Color Netural_4_Colour = Color(0xffF2F2F2);
Color Netural_5_Colour = Color(0xffFFFFFF);

//Sementic
Color Sementic_1_Colour = Color(0xffFF4267);
Color Sementic_2_Colour = Color(0xff52D5BA);
Color Sementic_3_Colour = Color(0xffFB6B18);
Color light_grey_Colour = Color(0xffD9D9D9);
Color divider_Colour = Color(0xffD8D8D8);
Color shadow_color = Color(0x0D000000);



// order_information
// const order_info_bg_color =  Color.fromARGB(255, 250, 250, 250);
// const white_color = Color(0xffffffff);
Color white_shadow_color = Colors.grey.shade200;
// Color light_grey = Color.fromARGB(255, 240, 240, 240);
// Color grey_color = Colors.grey;












