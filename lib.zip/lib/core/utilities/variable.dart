// ignore_for_file: constant_identifier_names

class Variable {
// order_information

  static const String tab1_title = "Journeys";
  static const String tab2_title = "Passed";
  static const String order_title = "Order 30528";
  static const String Tons = "12 Tons";
  static const String license_plate = "License plate:";
  static const String license_plate_no = "L30U-12345";
  static const String stepper_title = "Journey details";
  static const String trip1_title = "Antony driver takes the trip";
  static const String trip1_subtitle = "2020/03/21 - 09:00";
  static const String trip2_title = "Driver finished taking goods";
  static const String trip3_title = "On the journey";
  static const String trip4_title = "Delivery completed";
  static const String line_item = "Line item";
  static const String location1_title = "Los Angeles, Canifornia, USA";
  static const String location2_title = "Las Vegas, Canifornia, USA";
    static const String date = "2020/03/24 ";


  static const String order_info_heading = "Order information";
  static const String number_of_vehicles = "Number of vehicles";
  static const String row_size = "Row size";
  static const String lengthm = "Length(m)";
  static const String heightm = "Height(m)";
  static const String widthm = "Width(m)";
  static const String length = "Length";
  static const String height = "Height";
  static const String width = "Width";
  static const String add_photo = "Add photos";
  static const String types_of_service = "Type of vehicle service";
  static const String distinguish_car = "Distinguish the car?";
  static const String get_quote = "Get a quote";
  static const String what_does_it_mean = "Whats does it mean?";
  static const String textformfield_errro_message = "Minimum 14.3m";
  static const String notes_for_vehical_owner = "Notes for vehicle owners";

  // loading_point_info
  static const String loading_point_title = "Loading point information";
  static const String enter_location = "enter location";
  static const String detail_address = "Detailed Address";
  static const String full_name = "Full name";
  static const String telephone_no = "Telephone number";
  static const String point_contact_person = "Point contact person";
  static const String confirm = "Confirm";
  static const String cancel = "Cancel";

// driver_info
  static const String call = "Call";
  static const String order = "\$259.00 - Paid";
  static const String name = "Antony Rivia";
  static const String trucks_with_awning = "Trucks with awnings";
  static const String status = "Status";
  static const String found_driver = "Found a driver";
  static const String las_vegas = "Las Vegas";
  static const String los_angeles = "Los angeles";
  static const String see_details = "See details";
  static const String driver_info = "Driver information";
  static const String order_heading = "Order #30528";
  static const String how_is_your_ship = "How is your oder shipped by anthony?";
  static const String location_alert_subtitle = "Las Vegas, Canifornia, USA";

  //picking_point
    static const String enter_state = "enter state";
        static const String enter_district = "enter district";
            static const String state = "State";
        static const String district = "District";
                static const String picking_title = "Picking point";



}
