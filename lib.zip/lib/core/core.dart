export 'package:flutter/material.dart';
export 'package:get/get.dart';
export 'package:get_storage/get_storage.dart';
export 'package:truckgo_project/core/utilities/variable.dart';
export 'package:truckgo_project/core/utilities/style/color.dart';
export 'package:truckgo_project/core/utilities/style/style.dart';




