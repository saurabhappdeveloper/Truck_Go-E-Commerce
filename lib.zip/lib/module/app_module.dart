//common
export 'package:truckgo_project/core/utilities/widget_utilities/main_app_bar.dart';
export 'package:collection/collection.dart';
export 'package:dotted_border/dotted_border.dart';
export 'package:sizer/sizer.dart';
export 'package:google_maps_flutter/google_maps_flutter.dart';
export 'package:google_maps_flutter/google_maps_flutter.dart';
export 'package:flutter/services.dart';
export 'package:flutter_phone_direct_caller/flutter_phone_direct_caller.dart';
export 'package:truckgo_project/module/order/widgets/map.dart';



// picking point
export 'package:truckgo_project/module/picking_point/widgets/district_bottomsheet_design.dart';
export 'package:truckgo_project/module/picking_point/views/picking_point.dart';


//order
export 'package:truckgo_project/module/order/views/order_information.dart';
export 'package:truckgo_project/module/order/views/order_map.dart';
export 'package:truckgo_project/module/order/widgets/row_size_bottomsheet.dart';
export 'package:truckgo_project/module/order/widgets/truck_image_widget.dart';
export 'package:truckgo_project/module/order/views/order_map_driver_profile.dart';
export 'package:another_stepper/another_stepper.dart';
export 'package:truckgo_project/core/utilities/widget_utilities/appbar.dart';
export 'package:flutter_rating_bar/flutter_rating_bar.dart';
export 'package:image_picker/image_picker.dart';
export 'package:truckgo_project/module/order/widgets/stepper_progress.dart';





// driver information
export 'package:truckgo_project/module/driver_information/views/driver_information_page.dart';
export 'package:truckgo_project/module/order/widgets/order_driver_profile.dart';
export 'package:truckgo_project/module/order/widgets/loading_point_widget.dart';






