
import 'package:truckgo_project/core/core.dart';
import 'package:truckgo_project/module/app_module.dart';


void main() {
    WidgetsFlutterBinding.ensureInitialized();
  if (Get.isLogEnable) Get.isLogEnable = true;
  SystemChrome.setPreferredOrientations(
      [DeviceOrientation.portraitUp, DeviceOrientation.portraitDown]);
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return Sizer(
      builder: (context, orientation, deviceType) {
    return MaterialApp(
        title: 'Flutter Demo',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        home:
            order_information()
            // order_map()  
            // driver_information()
            // order_map_driver_profile()
            // picking_point()
            );
      });
  }
}


